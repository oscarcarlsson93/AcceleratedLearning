
//	function myFunction() {
//document.getElementbyId("minknapp").addEventListener("click", function(){
//	document.getElementbyId("MinRubrik").innerhtml
//}
//
