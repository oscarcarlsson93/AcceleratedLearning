﻿use Mvc02

select * from Product

select * from AspNetRoles
select * from AspNetUsers
select * from AspNetUserRoles