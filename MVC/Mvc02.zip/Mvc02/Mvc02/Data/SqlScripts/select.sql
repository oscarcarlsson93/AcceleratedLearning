﻿use Mvc02

select * from Product

select * from AspNetUsers