﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mvc02.Models.ViewModels
{
    public class UserTableVm
    {
        public List<UserWithRoles> Rows { get; set; }
    }
}
