﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Rememberall.Domains
{
    public class Activities
    {
        public int Id { get; set; }
        public string Activityname { get; set; }
        public DateTime Date { get; set; }
    }
}
