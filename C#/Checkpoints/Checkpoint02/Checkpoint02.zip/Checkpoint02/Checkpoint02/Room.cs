﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Checkpoint02
{
    class Room
    {
        public string Rumnamn { get; set; }
        public string Area { get; set; }
        
    }
}
