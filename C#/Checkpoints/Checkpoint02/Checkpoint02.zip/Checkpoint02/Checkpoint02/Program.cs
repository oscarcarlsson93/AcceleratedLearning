﻿using System;
using System.Collections.Generic;

namespace Checkpoint02
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Room> rumList = new List<Room>();

            Console.WriteLine("Ange namn på rum: ");
            string input = Console.ReadLine();
            Console.WriteLine();

            string[] rum = input.Split('|');
          
            foreach (var item in rum)
            {
                var rummen = new Room();

                string trimmad = item.Trim();
                string[] rumSplit = trimmad.Split(" ");
              
                
                rummen.Rumnamn = rumSplit[0];
                // rummen.Area = int.Parse(rumSplit[1]);
                rummen.Area = rumSplit[1];
                rumList.Add(rummen);

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"* Rumnamn {rumList.Count + 0}: {rumSplit[0]}");
                Console.ResetColor();
            }
           

           





        }
    }
}
