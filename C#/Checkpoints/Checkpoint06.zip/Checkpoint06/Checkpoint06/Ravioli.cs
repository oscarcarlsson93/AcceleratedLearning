﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Checkpoint06
{
   public class Ravioli
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        // public List<Ravioli> RavioliStorage { get; set; }
        public int ShipId { get; set; }


    }
}
