﻿
async function recreateDatabase() {
    document.getElementById("recreateButton").style.display = "none";
    document.body.style.backgroundColor = "blue";
    let response = await fetch("/observation/recreate", {
        method: "POST"
    });

    if (response.status === 200) {
        document.getElementById("recreateButton").style.display = "block";
        document.body.style.backgroundColor = "green";
        
    } else {
        document.getElementById("recreateButton").style.display = "block";
        document.body.style.backgroundColor = "red";

    }

}

async function addBird() {
    let addName = document.getElementById("addSpecie").value;

    console.log(addName);
    let response = await fetch("observation", {
        method: "POST",
        body: JSON.stringify(
            {
                name: addName,
            }),
        
        header: {
            "Content-Type": "application/json"
        }
    });
    console.log(response.status);
}

async function showAllObservs() {
    let response = await fetch("observations", { method: "GET" });
    console.log(response.status);
    document.getElementById("showAll").innerText = "";

    if (response.status === 200) {

        let array = await response.json();

        for (let i = 0; i < array.length; i++) {
            let obj = array[i];
            let para = document.createElement("p");
            let t = document.createTextNode("ID:" + obj.id + " Specie:" + obj.name);
            para.appendChild(t);
            document.getElementById("showAll").appendChild(para);

        }
    }
    else {
        console.error("Unexpected error", response);
    }
}
