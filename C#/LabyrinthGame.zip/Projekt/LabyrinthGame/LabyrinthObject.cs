﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabyrinthGame
{
    class LabyrinthObject
    {
        public Kordinat Kordinater;
        public ConsoleColor Color { get; set; }
        public char Symbol { get; set; }

    }
}
