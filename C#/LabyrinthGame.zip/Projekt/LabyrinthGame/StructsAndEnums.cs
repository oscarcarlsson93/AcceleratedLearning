﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabyrinthGame
{
    enum SquareStatus { wall, free }

    struct Kordinat
    {
        public int X;
        public int Y;
    }
   
}
