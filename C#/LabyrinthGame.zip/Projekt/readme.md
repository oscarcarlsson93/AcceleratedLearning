LabyrinthGame

Spelet går ut på att ta sig till målet. I spelnätet finns en dold labyrint. Varje gång man går in i ett hinder förflyttas spelaren tillbaka till sin startposition. Det gäller därför att komma ihåg var dessa hinder ligger så man kan nå målet. Når en spelare målet får denna ett poäng och ett nytt mål slumpas fram. 1-4 spelare. När en spelare får 3 poäng vinner denna.